const axios = require('axios');

axios.get('https://api.spotify.com/v1/search?q=lord+patawad&type=track', {
    headers: {
    'Authorization': 'Bearer BQClekbCqRXwi0nBDJIY4k4G3sqM3mk1yyEQ1nwhLIAmgxi_B08hTSeDcoJo-LHKUdWTG9-_bleUqGSJGhNTumsSaNd5QizPZQFlILSXi--dv8ToZaR7J52v952NnGVIrBpiM5MiIoV8h4wY94paP48d2qQfNEcmH5Wbej2Di5UdgdJmjzIp1YA4ZfDXAzRbkZQUmmAr7oAqqfqWAbQ'
}
}).then((data)=>{
    console.log(data.data.tracks.items[0].id);
})

